
public class Main4 {
	public static void main(String[] args) {
		String[] name = { "유림", "형섭", "배욱" };
		Person[] person = new Person[3];
		int endNum = 100;
	}
}
