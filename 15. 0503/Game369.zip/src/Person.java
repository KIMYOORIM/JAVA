
public class Person {
	String name = "";
	int currentNum = 0;
	int endNum = 0;
	String result = "";
	
	public Person(String name, int endNum) {
		// TODO Auto-generated constructor stub
		this.name = name;
		this.endNum = endNum;
	}
	
	private void print() {
		System.out.println(this.name + "이 외칩니다. " + result + "!!!!!!!!!");
	}
	
	//3,6,9를 체크해서 있다면 result 짝을 넣어주고, 아니면 숫자를 그대로 result에 저장한다
	private void checkCurrentNum() {
		result = "";
		String temp = String.valueOf(currentNum);
		
		int count = 0;
		for(int i = 0; i < temp.length(); i++) {
			if(temp.charAt(i) == '3' || temp.charAt(i) == '6' || temp.charAt(i) == '9') {
				result = result + "짝";
				count++;
			}
		}
		
		if(count == 0) {
			result = temp;
		}
		
		
	}
	
	public void setCurrent(int count) {
		this.currentNum = count;
		this.checkCurrentNum();
		this.print();
	}
}
