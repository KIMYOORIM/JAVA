
public class NumberClass {
	private int number = 0;
	
	
	public NumberClass(int num) {
		this.number = num;
		// TODO Auto-generated constructor stub
	}
	
	public void setNum(int number) {
		this.number = number;
	}
	
	public int getNum() {
		return this.number;
	}
}
