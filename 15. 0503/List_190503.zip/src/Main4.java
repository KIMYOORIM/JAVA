import java.util.HashMap;

public class Main4 {
	public static void main(String[] args) {
		String[] name = { "유림", "형섭", "배욱" };
		Person[] person = new Person[3];
		int endNum = 100;

		HashMap<Integer, Person> setPerson = new HashMap<Integer, Person>();
		for (int i = 0; i < name.length; i++) {
			setPerson.put(i, new Person(name[i], endNum));
		}
		
		HashMap<String, Person> setPerson2 = new HashMap<String, Person>();
		for (int i = 0; i < name.length; i++) {
			setPerson2.put(name[i], new Person(name[i], endNum));
		}

		//case 1 : array
		for (int i = 0; i < person.length; i++) {
			person[i] = new Person(name[i], endNum);
		}

		for (int i = 0; i < endNum; i++) {
			
			// case 1: array
			// person[i%3].setCurrent(i+1);

			//case 2 : key = Integer
			//setPerson.get(i % 3).setCurrent(i + 1);

			//case 3 : key = String
			setPerson2.get(name[i%3]).setCurrent(i+1);
		}
	}
}
